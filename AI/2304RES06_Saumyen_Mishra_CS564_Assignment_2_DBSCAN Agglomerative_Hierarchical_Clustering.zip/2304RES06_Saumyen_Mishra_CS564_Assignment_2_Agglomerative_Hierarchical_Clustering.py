import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import AgglomerativeClustering
from scipy.cluster.hierarchy import dendrogram, linkage
from sklearn.metrics import silhouette_score
import numpy as np

#*******************************************************************************************************************************************************************************
#*******************************************************************************************************************************************************************************

url = 'https://raw.githubusercontent.com/SaumyenMishraIITP/iris/main/students.csv'
student_db = pd.read_csv(url)

#print (student_db)
student_db = student_db.drop_duplicates()
#student_db.isnull().sum()
student_db = student_db.drop(['gender'], axis = 1)
student_db = student_db.drop(['age'], axis = 1)
#duplicates = student_db[student_db.duplicated()]
#print (duplicates)
student_db.isnull().sum()

tot_students = len(student_db.index)
tot_features = len(student_db.columns)

#*******************************************************************************************************************************************************************************
#*******************************************************************************************************************************************************************************

list_var = []
list_mean = []
Y1=[]

for a1 in range (0,tot_features,1) :
  Y1=[]
  Y1.append(student_db.iloc[:,[a1]].values)
  v1=np.var(Y1)
  list_var.append(v1)

list_var.remove(list_var[0])
list_var.remove(list_var[0])

print(f"\nVariance List : \n{list_var}\n")

feat=[]
for a3 in range (2, tot_features, 1) :
  feat.append(a3)

plt.plot(feat,list_var,color='blue', linestyle='dashed', linewidth = 2, marker='o', markerfacecolor='red', markersize=8)
plt.xlabel('Feature IDs')
plt.ylabel('Feature Variance')
plt.title('Feature Selection based on Variance')
plt.show()

delay=0
while delay<2000 :
  delay=delay+1

#*******************************************************************************************************************************************************************************
#*******************************************************************************************************************************************************************************

#print(tot_students)

list_gradyear = student_db.iloc[:,[0]].values
list_num_of_friends = student_db.iloc[:,[1]].values

unique_gradyears = student_db.gradyear.unique()   #[2007 2006 2008 2009]
tot_unique_gradyears = len(unique_gradyears)      #4

#*******************************************************************************************************************************************************************************
#*******************************************************************************************************************************************************************************

data_for_clustering_whole_batch = student_db.iloc[:,[2,3,4,5,6,9,10]].values

data_for_clustering_2007_batch = []
data_for_clustering_2006_batch = []
data_for_clustering_2008_batch = []
data_for_clustering_2009_batch = []
friends_2007 = []
friends_2006 = []
friends_2008 = []
friends_2009 = []

tot_students_2007_batch = 0
tot_students_2006_batch = 0
tot_students_2008_batch = 0
tot_students_2009_batch = 0


for i in range (0, tot_students, 1) :

   if student_db.iat[i,0] == unique_gradyears[0] :
      tot_students_2007_batch = tot_students_2007_batch + 1
      a = student_db.iloc[i,[2,3,4,5,6,9,10]].values
      friends_2007.append(student_db.iloc[i,[1]].values)
      data_for_clustering_2007_batch.append(a)

   elif student_db.iat[i,0] == unique_gradyears[1] :
      tot_students_2006_batch = tot_students_2006_batch + 1
      b = student_db.iloc[i,[2,3,4,5,6,9,10]].values
      friends_2006.append(student_db.iloc[i,[1]].values)
      data_for_clustering_2006_batch.append(b)

   elif student_db.iat[i,0] == unique_gradyears[2] :
      tot_students_2008_batch = tot_students_2008_batch + 1
      c = student_db.iloc[i,[2,3,4,5,6,9,10]].values
      friends_2008.append(student_db.iloc[i,[1]].values)
      data_for_clustering_2008_batch.append(c)

   elif student_db.iat[i,0] == unique_gradyears[3] :
      tot_students_2009_batch = tot_students_2009_batch + 1
      d = student_db.iloc[i,[2,3,4,5,6,9,10]].values
      friends_2009.append(student_db.iloc[i,[1]].values)
      data_for_clustering_2009_batch.append(d)

#*******************************************************************************************************************************************************************************
#*******************************************************************************************************************************************************************************

AHC_cluster_whole_batch = AgglomerativeClustering(n_clusters=None,linkage='single',distance_threshold =1)
AHC_cluster_whole_batch = AHC_cluster_whole_batch.fit(data_for_clustering_whole_batch)
CLUSTERS_1 = AHC_cluster_whole_batch.labels_
print (CLUSTERS_1)
tot_points = len(CLUSTERS_1)

print(f"\nTotal no. points considered for clustering the Whole Batch of Students is : {tot_points}\n")
clusters_1_set = set(CLUSTERS_1)
cluster_1_unique_lables = list(clusters_1_set)

count = len(cluster_1_unique_lables)
print(f"\n\nTotal Number of Clusters found for the complete batch with Agglomerative Hierarchical Clustering are : {count} \n\n")

X=[]
for j in range(0, count, 1) :
  X.append(0)

for labels in CLUSTERS_1 :
  for k in range (0, count, 1) :
    if labels == cluster_1_unique_lables[k] :
      X[k] = X[k] + 1
      break

tot=0
for p in range (0, len(X), 1) :
  print(f"\nNumber of Points corresponding to cluster label '{cluster_1_unique_lables[p]}' are : {X[p]}\n")
  tot=tot+X[p]

if tot==tot_points :
  print("\nALL POINTS HAVE BEEN SUCCESSFULLY PARTITIONED FOR THE COMPLETE BATCH\n")
else :
  print("\nPlease count properly\n")

#*******************************************************************************************************************************************************************************
#*******************************************************************************************************************************************************************************

plt.scatter(student_db.iloc[:,1], student_db.iloc[:,2] , c=CLUSTERS_1, cmap='seismic', s=50)
plt.xlabel('No. of Friends')
plt.ylabel('No. of times Selected for Basketball Team')
plt.title('Social Circle vs Basketball Team selections')
plt.show()

plt.scatter(student_db.iloc[:,1], student_db.iloc[:,3] , c=CLUSTERS_1, cmap='seismic', s=50)
plt.xlabel('No. of Friends')
plt.ylabel('No. of times Selected for Football Team')
plt.title('Social Circle vs Football Team selections')
plt.show()

plt.scatter(student_db.iloc[:,1], student_db.iloc[:,4] , c=CLUSTERS_1, cmap='seismic', s=50)
plt.xlabel('No. of Friends')
plt.ylabel('No. of times Selected for Soccer Team')
plt.title('Social Circle vs Soccer Team selections')
plt.show()

plt.scatter(student_db.iloc[:,1], student_db.iloc[:,5] , c=CLUSTERS_1, cmap='seismic', s=50)
plt.xlabel('No. of Friends')
plt.ylabel('No. of times Selected in Softball Team')
plt.title('Social Circle vs Softball Team selections')
plt.show()

plt.scatter(student_db.iloc[:,1], student_db.iloc[:,6] , c=CLUSTERS_1, cmap='seismic', s=50)
plt.xlabel('No. of Friends')
plt.ylabel('No. of times Selected in Volleyball Team')
plt.title('Social Circle vs Volleyball Team selections')
plt.show()

plt.scatter(student_db.iloc[:,1], student_db.iloc[:,9] , c=CLUSTERS_1, cmap='seismic', s=50)
plt.xlabel('No. of Friends')
plt.ylabel('No. of times Selected in Baseball Team')
plt.title('Social Circle vs Baseball Team selections')
plt.show()

plt.scatter(student_db.iloc[:,1], student_db.iloc[:,10] , c=CLUSTERS_1, cmap='seismic', s=50)
plt.xlabel('No. of Friends')
plt.ylabel('No. of times Selected in Tennis Team')
plt.title('Social Circle vs Tennis Team selections')
plt.show()

#*******************************************************************************************************************************************************************************
#*******************************************************************************************************************************************************************************

print("\n\n***************************************************************************************************************************************************\n")
print("***************************************************************************************************************************************************\n\n")

AHC_cluster_2007_batch = AgglomerativeClustering(n_clusters=None,linkage='single',distance_threshold =1)
AHC_cluster_2007_batch.fit(data_for_clustering_2007_batch)

CLUSTERS_2 = AHC_cluster_2007_batch.labels_
tot_points_2 = len(CLUSTERS_2)
print(f"\nTotal no. points considered for clustering the 2007 Batch Students is : {tot_points_2}\n")
#print(CLUSTERS_1)
clusters_2_set = set(CLUSTERS_2)
cluster_2_unique_lables = list(clusters_2_set)

count_1 = len(cluster_2_unique_lables)
print(f"\n\nTotal Number of Clusters for 2007 batch found with Agglomerative Hierarchical Clustering are : {count_1} \n\n")

X1=[]
for j1 in range(0, count_1, 1) :
  X1.append(0)

for labels_2 in CLUSTERS_2 :
  for k1 in range (0, count_1, 1) :
    if labels_2 == cluster_2_unique_lables[k1] :
      X1[k1] = X1[k1] + 1
      break

tot1=0
for p1 in range (0, len(X1), 1) :
  print(f"\nNumber of Points corresponding to cluster label '{cluster_2_unique_lables[p1]}' are : {X1[p1]}\n")
  tot1=tot1+X1[p1]

if tot1==tot_points_2 :
  print("\nALL POINTS HAVE BEEN SUCCESSFULLY PARTITIONED FOR 2007 BATCH\n")
else :
  print("\nPlease count properly\n")


#*******************************************************************************************************************************************************************************
#*******************************************************************************************************************************************************************************

z= len(data_for_clustering_2007_batch)
A1=[]
A2=[]
A3=[]
A4=[]
A5=[]
A6=[]
A7=[]

for u in range(0, z, 1) :
  A1.append(data_for_clustering_2007_batch[u][0])
  A2.append(data_for_clustering_2007_batch[u][1])
  A3.append(data_for_clustering_2007_batch[u][2])
  A4.append(data_for_clustering_2007_batch[u][3])
  A5.append(data_for_clustering_2007_batch[u][4])
  A6.append(data_for_clustering_2007_batch[u][5])
  A7.append(data_for_clustering_2007_batch[u][6])


plt.scatter(friends_2007, A1 , c=CLUSTERS_2, cmap='bwr', s=50)
plt.xlabel('No. of Friends')
plt.ylabel('No. of times Selected for Basketball Team')
plt.title('Social Circle vs Basketball Team selections in Batch of 2007')
plt.show()


plt.scatter(friends_2007, A2 , c=CLUSTERS_2, cmap='bwr', s=50)
plt.xlabel('No. of Friends')
plt.ylabel('No. of times Selected for Football Team')
plt.title('Social Circle vs Football Team selections in Batch of 2007')
plt.show()

plt.scatter(friends_2007, A3 , c=CLUSTERS_2, cmap='bwr', s=50)
plt.xlabel('No. of Friends')
plt.ylabel('No. of times Selected for Soccer Team')
plt.title('Social Circle vs Soccer Team selections in Batch of 2007')
plt.show()

plt.scatter(friends_2007, A4 , c=CLUSTERS_2, cmap='bwr', s=50)
plt.xlabel('No. of Friends')
plt.ylabel('No. of times Selected in Softball Team')
plt.title('Social Circle vs Softball Team selections in Batch of 2007')
plt.show()

plt.scatter(friends_2007, A5 , c=CLUSTERS_2, cmap='bwr', s=50)
plt.xlabel('No. of Friends')
plt.ylabel('No. of times Selected in Volleyball Team')
plt.title('Social Circle vs Volleyball Team selections in Batch of 2007')
plt.show()

plt.scatter(friends_2007, A6 , c=CLUSTERS_2, cmap='bwr', s=50)
plt.xlabel('No. of Friends')
plt.ylabel('No. of times Selected in Baseball Team')
plt.title('Social Circle vs Baseball Team selections in Batch of 2007')
plt.show()

plt.scatter(friends_2007, A7 , c=CLUSTERS_2, cmap='bwr', s=50)
plt.xlabel('No. of Friends')
plt.ylabel('No. of times Selected in Tennis Team')
plt.title('Social Circle vs Tennis Team selections in Batch of 2007')
plt.show()

#*******************************************************************************************************************************************************************************
#*******************************************************************************************************************************************************************************

g = sns.PairGrid(student_db.loc[:,["gradyear","NumberOffriends","basketball","football","soccer","softball","volleyball","baseball","tennis"]])
#g = sns.PairGrid(student_db.loc[:,["gradyear","NumberOffriends","Gender","dance","music","god","blonde"]])
#"step", which means the histogram will be drawn as a line plot.
g.map_diag(plt.hist, histtype="step", linewidth=3) # Diagonal subplots represent the distribution of each individual variable.
g.map_offdiag(plt.scatter) #Off-diagonal subplots represent the relationship between pairs of variables.

delay=0
while delay<2000 :
  delay=delay+1

#*******************************************************************************************************************************************************************************
#*******************************************************************************************************************************************************************************
  
Silhouette_1 = silhouette_score(data_for_clustering_whole_batch, CLUSTERS_1, metric='euclidean')
Silhouette_2 = silhouette_score(data_for_clustering_2007_batch, CLUSTERS_2, metric='euclidean')


print(f"\n\n\nSilhoutte score of the complete partitioning done for Whole Batch of Students is : {Silhouette_1}\n")
print(f"Silhoutte score of the complete partitioning done for only 'Batch of 2007' - Students is : {Silhouette_2}\n\n\n")

